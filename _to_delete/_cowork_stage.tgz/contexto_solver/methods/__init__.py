"""Solver method implementations."""

