"""Contexto evolutionary solver package."""

